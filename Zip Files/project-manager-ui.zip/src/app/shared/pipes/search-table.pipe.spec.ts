import { SearchTablePipe } from './search-table.pipe';

describe('SearchTablePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchTablePipe();
    expect(pipe).toBeTruthy();
  });
});
