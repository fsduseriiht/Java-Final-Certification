import { SearchContentPipe } from './search-content.pipe';

describe('SearchContentPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchContentPipe();
    expect(pipe).toBeTruthy();
  });
});
